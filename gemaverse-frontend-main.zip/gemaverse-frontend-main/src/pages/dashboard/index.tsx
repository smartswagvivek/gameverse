import DashboardIndex from '@/components/dashboard/DashboardIndex'
import React from 'react'

const index = () => {
  return (
    <div>
        <DashboardIndex />
    </div>
  )
}

export default index