import React from 'react'
import Link from 'next/link'

const LostPagge = () => {
    return (
        <div className='text-white'>

            <>
                <div className="container404 container-star">
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-1" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                    <div className="star-2" />
                </div>
                <div className="container404 container-bird">
                    <div className="bird bird-anim">
                        <div className="bird-container">
                            <div className="wing wing-left">
                                <div className="wing-left-top" />
                            </div>
                            <div className="wing wing-right">
                                <div className="wing-right-top" />
                            </div>
                        </div>
                    </div>
                    <div className="bird bird-anim">
                        <div className="bird-container">
                            <div className="wing wing-left">
                                <div className="wing-left-top" />
                            </div>
                            <div className="wing wing-right">
                                <div className="wing-right-top" />
                            </div>
                        </div>
                    </div>
                    <div className="bird bird-anim">
                        <div className="bird-container">
                            <div className="wing wing-left">
                                <div className="wing-left-top" />
                            </div>
                            <div className="wing wing-right">
                                <div className="wing-right-top" />
                            </div>
                        </div>
                    </div>
                    <div className="bird bird-anim">
                        <div className="bird-container">
                            <div className="wing wing-left">
                                <div className="wing-left-top" />
                            </div>
                            <div className="wing wing-right">
                                <div className="wing-right-top" />
                            </div>
                        </div>
                    </div>
                    <div className="bird bird-anim">
                        <div className="bird-container">
                            <div className="wing wing-left">
                                <div className="wing-left-top" />
                            </div>
                            <div className="wing wing-right">
                                <div className="wing-right-top" />
                            </div>
                        </div>
                    </div>
                    <div className="bird bird-anim">
                        <div className="bird-container">
                            <div className="wing wing-left">
                                <div className="wing-left-top" />
                            </div>
                            <div className="wing wing-right">
                                <div className="wing-right-top" />
                            </div>
                        </div>
                    </div>
                    <div className="container-title">
                        <div className="flex items-center gap-3">
                            <div className="number">4</div>
                            <div className="moon">
                                <div className="face">
                                    <div className="mouth" />
                                    <div className="eyes">
                                        <div className="eye-left" />
                                        <div className="eye-right" />
                                    </div>
                                </div>
                            </div>
                            <div className="number">4</div>
                        </div>
                        <div className="subtitle">Oops! Page Not Found.</div>
                        <br />
                        <Link href={"/dashboard"}>
                            <p className='underline'>GO BACK.</p>
                        </Link>
                    </div>
                </div>
            </>

        </div>
    )
}

export default LostPagge